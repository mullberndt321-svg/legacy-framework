Config = {}

Config.Fade = true
